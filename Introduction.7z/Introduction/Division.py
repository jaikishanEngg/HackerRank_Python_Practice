'''
Problem statement:
https://www.hackerrank.com/challenges/python-division
'''

if __name__ == '__main__':
    a = int(input())
    b = int(input())
    print((int)(a/b))
    print(a/b)