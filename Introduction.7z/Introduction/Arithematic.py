'''
Problem statement:
https://www.hackerrank.com/challenges/python-arithmetic-operators/problem
'''

if __name__ == '__main__':
    a = int(input())
    b = int(input())
    print(a+b)
    print(a-b)
    print(a*b)