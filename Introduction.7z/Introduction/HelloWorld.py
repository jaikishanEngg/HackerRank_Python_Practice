'''
Problem statement:
https://www.hackerrank.com/challenges/py-hello-world
'''
print("Hello, World!")